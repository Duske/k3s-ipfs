from multi_rake.algorithm import Rake  # noqa
